import { useCallback, useEffect, useMemo, useState } from 'react';
import { BookOpen, CheckCircle2, ChevronRight, CircleHelp, ClipboardList, LogOut, Mail, Menu, QrCode, RefreshCw, ScanLine, ShieldAlert, ShieldCheck, Smartphone, UserRound, X } from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import { Html5QrcodeScanner } from 'html5-qrcode';
import type { User } from '@supabase/supabase-js';
import { supabase } from './lib/supabase';

type Tab = 'home' | 'qr' | 'scan' | 'classes' | 'reports' | 'about';
type Membership = { role: string; school_id: string; schools: { name: string } | null };
type ClassRow = { id: string; name: string };
type ScanResult = { verified?: boolean; display_name?: string; error?: string };
const tabs: { id: Tab; label: string; icon: typeof BookOpen }[] = [
  { id: 'home', label: 'Огляд', icon: BookOpen }, { id: 'qr', label: 'Мій QR-код', icon: QrCode },
  { id: 'scan', label: 'Сканер', icon: ScanLine }, { id: 'classes', label: 'Мої класи', icon: ClipboardList },
  { id: 'reports', label: 'Безпека', icon: ShieldAlert }, { id: 'about', label: 'Про платформу', icon: CircleHelp },
];
const friendlyError = (error: unknown) => {
  const message = error instanceof Error ? error.message : '';
  if (/invalid login credentials|invalid otp|token has expired/i.test(message)) return 'Код недійсний або строк його дії минув. Перевірте код і спробуйте ще раз.';
  if (/network|fetch/i.test(message)) return 'Не вдалося з’єднатися із сервісом. Перевірте інтернет і повторіть спробу.';
  return message || 'Сталася помилка. Спробуйте ще раз.';
};

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [mode, setMode] = useState<'email' | 'phone'>('email');
  const [otp, setOtp] = useState('');
  const [sent, setSent] = useState(false);
  const [notice, setNotice] = useState('');
  const [noticeType, setNoticeType] = useState<'info' | 'error' | 'success'>('info');
  const [tab, setTab] = useState<Tab>('home');
  const [membership, setMembership] = useState<Membership | null>(null);
  const [classes, setClasses] = useState<ClassRow[]>([]);
  const [classesLoading, setClassesLoading] = useState(false);
  const [token, setToken] = useState('');
  const [tokenExpiry, setTokenExpiry] = useState('');
  const [qrLoading, setQrLoading] = useState(false);
  const [scanResult, setScanResult] = useState<ScanResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [mobileMenu, setMobileMenu] = useState(false);

  const showNotice = useCallback((text: string, type: 'info' | 'error' | 'success' = 'info') => {
    setNotice(text); setNoticeType(type);
  }, []);

  useEffect(() => {
    if (!supabase) { setAuthReady(true); showNotice('Потрібно налаштувати Supabase у змінних середовища.', 'error'); return; }
    let active = true;
    supabase.auth.getSession().then(({ data, error }) => {
      if (!active) return;
      if (error) showNotice(friendlyError(error), 'error');
      setUser(data.session?.user ?? null); setAuthReady(true);
    }).catch((error: unknown) => { if (active) { showNotice(friendlyError(error), 'error'); setAuthReady(true); } });
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => setUser(session?.user ?? null));
    return () => { active = false; subscription.unsubscribe(); };
  }, [showNotice]);

  useEffect(() => {
    if (!user || !supabase) { setMembership(null); setClasses([]); return; }
    let active = true;
    (async () => {
      const { data, error } = await supabase.from('school_memberships')
        .select('role,school_id,schools(name)').eq('user_id', user.id).eq('state', 'active').limit(1).maybeSingle();
      if (!active) return;
      if (error) { showNotice('Не вдалося завантажити членство школи. Перевірте налаштування бази.', 'error'); return; }
      setMembership(data as unknown as Membership | null);
    })();
    return () => { active = false; };
  }, [user, showNotice]);

  const schoolName = membership?.schools?.name ?? 'Школу ще не підключено';
  const userLabel = user?.email || user?.phone || 'Користувач';
  const pageTitle = useMemo(() => tabs.find((item) => item.id === tab)?.label ?? 'Огляд', [tab]);

  async function sendCode() {
    if (!supabase) { showNotice('Supabase не налаштовано.', 'error'); return; }
    setLoading(true); setNotice('');
    try {
      if (mode === 'email') {
        const { error } = await supabase.auth.signInWithOtp({ email: email.trim(), options: { shouldCreateUser: true } });
        if (error) throw error;
      } else {
        const { error } = await supabase.auth.signInWithOtp({ phone: phone.trim() });
        if (error) throw error;
      }
      setSent(true); setOtp(''); showNotice('Якщо контакт підтримується налаштуваннями Auth, код або посилання вже надіслано.', 'success');
    } catch (error) { showNotice(friendlyError(error), 'error'); }
    finally { setLoading(false); }
  }
  async function verifyCode() {
    if (!supabase) return;
    setLoading(true);
    try {
      const result = mode === 'email'
        ? await supabase.auth.verifyOtp({ email: email.trim(), token: otp.trim(), type: 'email' })
        : await supabase.auth.verifyOtp({ phone: phone.trim(), token: otp.trim(), type: 'sms' });
      if (result.error) throw result.error;
      setSent(false); setOtp(''); showNotice('Вхід підтверджено.', 'success');
    } catch (error) { showNotice(friendlyError(error), 'error'); }
    finally { setLoading(false); }
  }
  async function logout() {
    if (!supabase) return;
    setLoading(true);
    const { error } = await supabase.auth.signOut();
    setLoading(false);
    if (error) showNotice(friendlyError(error), 'error'); else { setUser(null); setTab('home'); setToken(''); showNotice('Ви вийшли з акаунта.', 'success'); }
  }
  const createQr = useCallback(async () => {
    if (!supabase) return;
    setQrLoading(true); setToken(''); setTokenExpiry('');
    const { data, error } = await supabase.functions.invoke('qr-token', { body: { action: 'mint' } });
    setQrLoading(false);
    if (error) { showNotice(friendlyError(error), 'error'); return; }
    if (!data?.token || !data?.expires_at) { showNotice('Сервер не повернув QR-токен. Перевірте функцію qr-token.', 'error'); return; }
    setToken(data.token); setTokenExpiry(data.expires_at); showNotice('Створено тимчасовий QR-код.', 'success');
  }, [showNotice]);
  useEffect(() => { if (tab === 'qr' && user && !token && !qrLoading) void createQr(); }, [tab, user, token, qrLoading, createQr]);

  useEffect(() => {
    if (tab !== 'classes' || !user || !supabase || !membership) return;
    let active = true; setClassesLoading(true);
    (async () => {
      const { data, error } = await supabase.from('classes').select('id,name').eq('school_id', membership.school_id).order('name');
      if (!active) return;
      setClassesLoading(false);
      if (error) showNotice('Не вдалося завантажити класи. Перевірте доступи бази даних.', 'error');
      else setClasses((data ?? []) as ClassRow[]);
    })();
    return () => { active = false; };
  }, [tab, user, membership, showNotice]);

  useEffect(() => {
    if (tab !== 'scan' || !user || !supabase) return;
    const element = document.getElementById('qr-reader');
    if (!element) return;
    let active = true;
    const scanner = new Html5QrcodeScanner('qr-reader', { fps: 8, qrbox: { width: 230, height: 230 }, rememberLastUsedCamera: true }, false);
    scanner.render(async (decoded) => {
      if (!active) return;
      await scanner.clear().catch(() => undefined);
      const { data, error } = await supabase.functions.invoke('qr-token', { body: { action: 'verify', token: decoded } });
      if (!active) return;
      if (error) { setScanResult({ error: friendlyError(error) }); showNotice('Не вдалося перевірити QR-код.', 'error'); }
      else if (!data?.verified) { setScanResult({ error: 'Сервер не підтвердив QR-код.' }); }
      else { setScanResult({ verified: true, display_name: data.display_name }); showNotice('QR-код перевірено сервером.', 'success'); }
    }, () => undefined);
    return () => { active = false; void scanner.clear().catch(() => undefined); };
  }, [tab, user, showNotice]);

  if (!authReady) return <main className="loading-screen"><div className="brandmark">Є</div><p>Завантажуємо Є-Гідність…</p></main>;
  if (!user) return <main className="auth-screen"><section className="auth-card">
    <Brand /><div className="auth-intro"><span className="eyebrow">Захищений шкільний простір</span><h1>{sent ? 'Підтвердження входу' : 'Раді вас бачити'}</h1><p>Увійдіть, щоб перейти до інструментів своєї шкільної спільноти.</p></div>
    {!sent ? <>
      <div className="segmented" role="group" aria-label="Спосіб входу"><button className={mode === 'email' ? 'active' : ''} onClick={() => { setMode('email'); setNotice(''); }}><Mail size={16}/> Email</button><button className={mode === 'phone' ? 'active' : ''} onClick={() => { setMode('phone'); setNotice(''); }}><Smartphone size={16}/> Телефон</button></div>
      <label htmlFor="login-contact">{mode === 'email' ? 'Електронна пошта' : 'Телефон у міжнародному форматі'}</label>
      <input id="login-contact" type={mode === 'email' ? 'email' : 'tel'} autoComplete={mode === 'email' ? 'email' : 'tel'} value={mode === 'email' ? email : phone} onChange={(e) => mode === 'email' ? setEmail(e.target.value) : setPhone(e.target.value)} placeholder={mode === 'email' ? 'name@example.com' : '+380…'} />
      <button className="primary full" disabled={loading || !(mode === 'email' ? email.trim() : phone.trim())} onClick={() => void sendCode()}>{loading ? 'Надсилаємо…' : 'Надіслати код'}</button>
    </> : <>
      <label htmlFor="otp">Код підтвердження</label><input id="otp" inputMode="numeric" autoComplete="one-time-code" value={otp} onChange={(e) => setOtp(e.target.value)} placeholder="Введіть код із повідомлення" />
      <button className="primary full" disabled={loading || !otp.trim()} onClick={() => void verifyCode()}>{loading ? 'Перевіряємо…' : 'Підтвердити вхід'}</button>
      <button className="quiet full" onClick={() => { setSent(false); setOtp(''); setNotice(''); }}>Змінити контакт</button>
    </>}
    {notice && <p className={`notice ${noticeType}`} role="status" aria-live="polite">{notice}</p>}
    <p className="privacy-note"><ShieldCheck size={15}/> Нікому не повідомляйте код входу. Телефонний вхід потребує налаштованого SMS-провайдера.</p>
  </section></main>;

  return <div className="app-shell">
    <aside className={`sidebar ${mobileMenu ? 'open' : ''}`}>
      <div className="sidebar-top"><Brand /><button className="mobile-close icon-button" aria-label="Закрити меню" onClick={() => setMobileMenu(false)}><X size={19}/></button></div>
      <div className="nav-caption">ПРОСТІР</div><nav aria-label="Головна навігація">{tabs.map(({ id, label, icon: Icon }) => <button key={id} className={`nav-item ${tab === id ? 'selected' : ''}`} onClick={() => { setTab(id); setMobileMenu(false); setScanResult(null); setNotice(''); }}><Icon size={18}/><span>{label}</span>{tab === id && <ChevronRight className="nav-chevron" size={15}/>}</button>)}</nav>
      <div className="sidebar-bottom"><div className="account"><span className="account-avatar"><UserRound size={17}/></span><div className="account-info"><b>{userLabel}</b><small>{membership?.role ?? 'Без активного членства'}</small></div></div><button className="logout" onClick={() => void logout()} disabled={loading}><LogOut size={16}/><span>Вийти</span></button></div>
    </aside>
    {mobileMenu && <button className="scrim" aria-label="Закрити меню" onClick={() => setMobileMenu(false)} />}
    <main className="main-area"><header className="topbar"><button className="mobile-menu icon-button" aria-label="Відкрити меню" onClick={() => setMobileMenu(true)}><Menu size={21}/></button><div className="breadcrumb"><span>Є-Гідність</span><span className="crumb-sep">/</span><b>{pageTitle}</b></div><div className="school-chip"><span className="status-dot"/>{schoolName}</div></header>
      <div className="page-content">
        {notice && <div className={`notice global-notice ${noticeType}`} role="status" aria-live="polite"><span>{notice}</span><button className="notice-close" aria-label="Закрити повідомлення" onClick={() => setNotice('')}><X size={15}/></button></div>}
        <div className="page-heading"><div><span className="eyebrow">ВАША ШКІЛЬНА СПІЛЬНОТА</span><h1>{pageTitle}</h1><p>{tab === 'home' ? 'Інструменти для щоденної взаємодії та безпечної комунікації.' : 'Єдиний простір для учнів, батьків і працівників школи.'}</p></div><span className="secure-pill"><ShieldCheck size={15}/> Сесія активна</span></div>
        {tab === 'home' && <>
          <section className="hero-panel"><div className="hero-copy"><span className="hero-kicker"><span className="hero-kicker-dot"/> Є-ГІДНІСТЬ</span><h2>Твоя школа.<br/>Твої люди. Твій простір.</h2><p>Цифровий простір, що допомагає шкільній спільноті залишатися на зв’язку та дбати про безпеку.</p><button className="hero-button" onClick={() => setTab('qr')}>Відкрити мій QR-код <ChevronRight size={16}/></button></div><div className="hero-emblem" aria-hidden="true"><div className="emblem-ring"><span>Є</span></div><div className="emblem-caption"><ShieldCheck size={13}/> Простір довіри</div></div></section>
          <div className="section-title"><div><h2>Швидкий доступ</h2><p>Перейдіть до потрібного інструмента.</p></div></div>
          <div className="quick-grid"><button className="quick-card" onClick={() => setTab('qr')}><span className="quick-icon"><QrCode size={19}/></span><b>Мій QR-код</b><span>Тимчасовий код для перевірки</span><ChevronRight className="quick-arrow" size={16}/></button><button className="quick-card" onClick={() => setTab('classes')}><span className="quick-icon"><ClipboardList size={19}/></span><b>Мої класи</b><span>Класи вашої школи</span><ChevronRight className="quick-arrow" size={16}/></button><button className="quick-card" onClick={() => setTab('reports')}><span className="quick-icon"><ShieldAlert size={19}/></span><b>Безпека</b><span>Інформація про звернення</span><ChevronRight className="quick-arrow" size={16}/></button></div>
          <section className="info-strip"><ShieldCheck size={18}/><div><b>Безпека має значення</b><p>Доступ до даних визначається серверними правилами. Не надсилайте через неперевірену систему приватні дані або термінові повідомлення про небезпеку.</p></div></section>
        </>}
        {tab === 'qr' && <section className="content-card qr-layout"><div className="card-copy"><span className="eyebrow">ПЕРЕВІРКА УЧАСНИКА</span><h2>Ваш тимчасовий QR-код</h2><p>Код створюється сервером, має обмежений строк дії та не містить відкритих персональних даних.</p><div className="qr-facts"><div><span className="fact-icon"><RefreshCw size={15}/></span><span><b>Одноразовий токен</b><small>Після використання код має стати недійсним.</small></span></div><div><span className="fact-icon"><ShieldCheck size={15}/></span><span><b>Серверна перевірка</b><small>Результат перевіряється на сервері.</small></span></div></div><button className="secondary-button" onClick={() => void createQr()} disabled={qrLoading}><RefreshCw size={16} className={qrLoading ? 'spin' : ''}/>{qrLoading ? 'Створюємо…' : 'Створити новий код'}</button></div><div className="qr-card"><div className="qr-frame">{token ? <QRCodeSVG value={token} size={208} level="M" includeMargin/> : <div className="qr-placeholder">{qrLoading ? <RefreshCw className="spin" size={24}/> : <QrCode size={35}/>}<span>{qrLoading ? 'Готуємо код…' : 'QR-код недоступний'}</span></div>}</div><span className="qr-expiry">{tokenExpiry ? `Дійсний до ${new Date(tokenExpiry).toLocaleTimeString('uk-UA', { hour: '2-digit', minute: '2-digit' })}` : 'Строк дії визначає сервер'}</span></div><p className="inline-warning">Не використовуйте QR як самостійний доказ особи. Перевірка доступна лише уповноваженим учасникам налаштованої школи.</p></section>}
        {tab === 'scan' && <section className="content-card scan-card"><div className="module-heading"><span className="module-icon"><ScanLine size={19}/></span><div><h2>Сканер QR-коду</h2><p>Сканування доступне вчителям та іншим уповноваженим ролям школи.</p></div></div>{!membership || !['teacher','director','informatics_teacher','deputy_principal'].includes(membership.role) ? <div className="empty-state"><ShieldCheck size={25}/><b>Немає доступу до сканера</b><p>Потрібне активне членство з відповідними правами у школі.</p></div> : <><div id="qr-reader" className="qr-reader"/><p className="subtle-note">Дозвольте браузеру доступ до камери. Для роботи потрібне HTTPS-з’єднання.</p></>}{scanResult && <div className={`scan-result ${scanResult.error ? 'failed' : 'passed'}`}>{scanResult.error ? <><ShieldAlert size={18}/><div><b>Не вдалося перевірити код</b><p>{scanResult.error}</p></div></> : <><CheckCircle2 size={18}/><div><b>Код підтверджено</b><p>Ім’я з профілю: {scanResult.display_name || 'не вказано'}</p></div></>}</div>}</section>}
        {tab === 'classes' && <section className="content-card"><div className="module-heading"><span className="module-icon"><BookOpen size={19}/></span><div><h2>Класи школи</h2><p>Список класів, доступних у межах вашого членства.</p></div></div>{!membership ? <div className="empty-state"><UsersIcon/><b>Школу ще не підключено</b><p>Після підтвердження членства тут з’являться доступні класи.</p></div> : classesLoading ? <div className="empty-state">Завантажуємо класи…</div> : classes.length ? <div className="class-list">{classes.map((item) => <div className="class-row" key={item.id}><span className="class-symbol"><BookOpen size={17}/></span><b>{item.name}</b><span className="class-tag">Клас</span></div>)}</div> : <div className="empty-state"><BookOpen size={25}/><b>Поки немає класів</b><p>Коли адміністратор школи створить класи, вони відобразяться тут.</p></div>}</section>}
        {tab === 'reports' && <section className="content-card safety-card"><div className="safety-mark"><ShieldAlert size={23}/></div><span className="eyebrow">ПІДТРИМКА ТА БЕЗПЕКА</span><h2>Важливо, щоб тебе почули</h2><p>Функція безпечних звернень ще не підключена до перевіреного процесу обробки. Ми не будемо створювати фальшиву форму або обіцяти анонімність, яку система поки не гарантує.</p><div className="safety-actions"><div><b>Потрібна допомога зараз?</b><span>Звернися до дорослого, якому довіряєш, або до відповідальних служб у разі безпосередньої небезпеки.</span></div></div></section>}
        {tab === 'about' && <section className="content-card about-card"><div className="about-logo">Є</div><span className="eyebrow">ПРО ПЛАТФОРМУ</span><h2>Є-Гідність</h2><p className="about-lead">Цифровий простір для безпечної комунікації шкільної спільноти.</p><div className="about-divider"/><span className="about-label">Розробник платформи</span><b className="developer-name">Крет Дмитро Сергійович</b><span className="about-copy">Твоя школа. Твої люди. Твій простір.</span></section>}
        <footer className="page-footer"><span>© 2026 Є-Гідність</span><span>Розробник платформи: Крет Дмитро Сергійович</span></footer>
      </div>
    </main>
  </div>;
}
function Brand() { return <div className="brand"><span className="brandmark">Є</span><span className="brand-text"><b>Є-Гідність</b><small>Твоя школа. Твій простір.</small></span></div>; }
function UsersIcon() { return <UserRound size={25}/>; }
