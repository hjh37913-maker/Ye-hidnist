// Supabase Edge Function: mint or verify a short-lived QR bearer token.
// Deploy with: supabase functions deploy qr-token
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const cors={ "Access-Control-Allow-Origin":"*", "Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type", "Access-Control-Allow-Methods":"POST, OPTIONS" };
const json=(body:unknown,status=200)=>new Response(JSON.stringify(body),{status,headers:{...cors,"Content-Type":"application/json"}});
const sha=async(v:string)=>Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256",new TextEncoder().encode(v)))).map(x=>x.toString(16).padStart(2,"0")).join("");
Deno.serve(async(req)=>{
 if(req.method==="OPTIONS")return new Response("ok",{headers:cors}); if(req.method!=="POST")return json({error:"POST only"},405);
 const url=Deno.env.get("SUPABASE_URL")!, anon=Deno.env.get("SUPABASE_ANON_KEY")!, service=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
 const auth=req.headers.get("Authorization")||"";
 const userClient=createClient(url,anon,{global:{headers:{Authorization:auth}}});
 const {data:{user},error:authErr}=await userClient.auth.getUser(); if(authErr||!user)return json({error:"Unauthorized"},401);
 const admin=createClient(url,service);
 const body=await req.json().catch(()=>({}));
 if(body.action==="mint"){
   const {data:membership,error}=await admin.from("school_memberships").select("school_id").eq("user_id",user.id).eq("state","active").limit(1).maybeSingle();
   if(error||!membership)return json({error:"No active school membership"},403);
   const token=crypto.randomUUID()+"."+crypto.randomUUID();
   const hash=await sha(token); const expires=new Date(Date.now()+90_000).toISOString();
   const {error:insertErr}=await admin.from("qr_tokens").insert({user_id:user.id,school_id:membership.school_id,token_hash:hash,expires_at:expires});
   if(insertErr)return json({error:"Could not create token"},500);
   return json({token,expires_at:expires});
 }
 if(body.action==="verify"){
   const token=String(body.token||""); if(token.length>200||!token.includes("."))return json({error:"Invalid QR"},400);
   const hash=await sha(token);
   const {data:row,error}=await admin.from("qr_tokens").select("id,user_id,school_id,expires_at,used_at").eq("token_hash",hash).maybeSingle();
   if(error||!row||row.used_at||new Date(row.expires_at).getTime()<Date.now())return json({error:"QR expired, invalid, or already used"},400);
   const {data:scannerMembership}=await admin.from("school_memberships").select("role").eq("user_id",user.id).eq("school_id",row.school_id).eq("state","active").maybeSingle();
   if(!scannerMembership||!["teacher","director","informatics_teacher","deputy_principal"].includes(scannerMembership.role))return json({error:"No permission to scan for this school"},403);
   const {data:consumed,error:useErr}=await admin.from("qr_tokens").update({used_at:new Date().toISOString()}).eq("id",row.id).is("used_at",null).select("id").maybeSingle();
   if(useErr)return json({error:"Could not consume QR"},500);
   if(!consumed)return json({error:"QR already used"},409);
   const {data:profile}=await admin.from("profiles").select("display_name").eq("id",row.user_id).maybeSingle();
   return json({verified:true,display_name:profile?.display_name||"Учасник"});
 }
 return json({error:"Unknown action"},400);
});
