create extension if not exists pgcrypto;
create type public.member_role as enum('director','informatics_teacher','deputy_principal','teacher','student','parent');
create type public.member_state as enum('pending','active','suspended');
create table public.profiles(id uuid primary key references auth.users(id) on delete cascade,display_name text,created_at timestamptz not null default now());
create table public.schools(id uuid primary key default gen_random_uuid(),name text not null,status text not null default 'active',created_at timestamptz not null default now());
-- Automatically create a minimal profile for every newly registered Auth user.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public,pg_temp as $$
begin
  insert into public.profiles(id,display_name)
  values(new.id,coalesce(new.raw_user_meta_data->>'display_name',''))
  on conflict(id) do nothing;
  return new;
end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

create table public.school_memberships(id uuid primary key default gen_random_uuid(),school_id uuid not null references public.schools(id) on delete cascade,user_id uuid not null references public.profiles(id) on delete cascade,role public.member_role not null,state public.member_state not null default 'pending',created_at timestamptz not null default now(),unique(school_id,user_id));
create table public.classes(id uuid primary key default gen_random_uuid(),school_id uuid not null references public.schools(id) on delete cascade,name text not null,created_at timestamptz not null default now());
create table public.class_memberships(class_id uuid not null references public.classes(id) on delete cascade,membership_id uuid not null references public.school_memberships(id) on delete cascade,primary key(class_id,membership_id));
create table public.platform_admins(user_id uuid primary key references public.profiles(id) on delete cascade,active boolean not null default true);
create table public.qr_tokens(id uuid primary key default gen_random_uuid(),user_id uuid not null references public.profiles(id) on delete cascade,school_id uuid not null references public.schools(id) on delete cascade,token_hash text not null unique,expires_at timestamptz not null,used_at timestamptz,created_at timestamptz not null default now());
alter table public.profiles enable row level security; alter table public.schools enable row level security; alter table public.school_memberships enable row level security; alter table public.classes enable row level security; alter table public.class_memberships enable row level security; alter table public.platform_admins enable row level security; alter table public.qr_tokens enable row level security;
create or replace function public.is_member(sid uuid) returns boolean language sql stable security definer set search_path=public,pg_temp as $$ select exists(select 1 from public.school_memberships m where m.school_id=sid and m.user_id=auth.uid() and m.state='active') $$;
create or replace function public.is_platform_admin() returns boolean language sql stable security definer set search_path=public,pg_temp as $$ select exists(select 1 from public.platform_admins p where p.user_id=auth.uid() and p.active) $$;
create policy "profile own read" on public.profiles for select to authenticated using(id=auth.uid());
create policy "profile own update" on public.profiles for update to authenticated using(id=auth.uid()) with check(id=auth.uid());
create policy "member reads school" on public.schools for select to authenticated using(public.is_member(id));
create policy "member reads memberships" on public.school_memberships for select to authenticated using(public.is_member(school_id));
create policy "member reads classes" on public.classes for select to authenticated using(public.is_member(school_id));
create policy "member reads class memberships" on public.class_memberships for select to authenticated using(exists(select 1 from public.classes c where c.id=class_id and public.is_member(c.school_id)));
create policy "platform admin sees admin list" on public.platform_admins for select to authenticated using(user_id=auth.uid());
create policy "platform admin sees schools" on public.schools for all to authenticated using(public.is_platform_admin()) with check(public.is_platform_admin());
-- QR-token rows are never exposed directly to the browser; only Edge Function service logic handles them.
revoke all on public.qr_tokens from anon, authenticated;
grant select on public.profiles,public.schools,public.school_memberships,public.classes,public.class_memberships to authenticated;
-- Production follow-up: explicit role assignment/admin RPC, audit events, reports, invitation flow,
-- profile provisioning trigger, table grants review and automated cross-tenant RLS tests.
